/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type InterpreterStatus = 'available' | 'on-call' | 'break' | 'training' | 'offline';

export interface PerformanceMetrics {
  aht: string; // Average Handle Time (e.g., "04:12")
  csat: number; // Customer Satisfaction (0-5)
  callsTaken: number;
}

export interface Wave {
  id: string;
  name: string;
  startDate: string;
  interpreterCount: number;
  averageCsat: number;
}

export interface Interpreter {
  id: string;
  name: string;
  email: string;
  status: InterpreterStatus;
  languages: string[];
  specialties: string[];
  metrics: PerformanceMetrics;
  lastActive: string;
  waveId: string;
  avatar?: string;
}

export interface RosterStats {
  total: number;
  available: number;
  onCall: number;
  onBreak: number;
  averageCsat: number;
}
