/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Users, 
  PhoneCall, 
  Coffee, 
  GraduationCap, 
  Clock, 
  Star, 
  Globe,
  Filter,
  ArrowUpRight,
  MoreVertical,
  Activity,
  LayoutGrid,
  List
} from 'lucide-react';
import { Interpreter, InterpreterStatus, Wave } from './types';
import { MOCK_INTERPRETERS, MOCK_WAVES, LANGUAGES, SPECIALTIES } from './constants';

export default function App() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<InterpreterStatus | 'all'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table' | 'waves'>('grid');
  const [selectedInterpreter, setSelectedInterpreter] = useState<Interpreter | null>(null);

  const filteredInterpreters = useMemo(() => {
    return MOCK_INTERPRETERS.filter((interpreter) => {
      const matchesSearch = interpreter.name.toLowerCase().includes(search.toLowerCase()) ||
                          interpreter.id.toLowerCase().includes(search.toLowerCase()) ||
                          interpreter.languages.some(l => l.toLowerCase().includes(search.toLowerCase()));
      const matchesStatus = statusFilter === 'all' || interpreter.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [search, statusFilter]);

  const stats = useMemo(() => {
    return {
      total: MOCK_INTERPRETERS.length,
      available: MOCK_INTERPRETERS.filter(i => i.status === 'available').length,
      onCall: MOCK_INTERPRETERS.filter(i => i.status === 'on-call').length,
      onBreak: MOCK_INTERPRETERS.filter(i => i.status === 'break').length,
      avgCsat: (MOCK_INTERPRETERS.reduce((acc, i) => acc + i.metrics.csat, 0) / MOCK_INTERPRETERS.length).toFixed(1)
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0C10] text-[#E2E8F0] font-sans selection:bg-blue-500/30 flex">
      {/* Sidebar */}
      <aside className="w-64 glass border-r border-[#1E293B] hidden lg:flex flex-col p-6 sticky top-0 h-screen">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]">V</div>
          <h1 className="text-xl font-bold tracking-tight">VOX<span className="text-blue-500">LINK</span></h1>
        </div>
        
        <nav className="flex-1 space-y-1">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Operaciones</div>
          <a 
            href="#" 
            onClick={(e) => { e.preventDefault(); setViewMode('grid'); }}
            className={`flex items-center gap-3 p-3 rounded-lg transition-all relative group ${viewMode !== 'waves' ? 'bg-blue-600/10 text-blue-400' : 'text-slate-400 hover:bg-white/5'}`}
          >
            <Users size={18} />
            <span className="text-sm font-medium">Vista Roster</span>
            {viewMode !== 'waves' && <div className="absolute left-0 top-2 bottom-2 w-1 bg-blue-500 rounded-full" />}
          </a>
          <a 
            href="#" 
            onClick={(e) => { e.preventDefault(); setViewMode('waves'); }}
            className={`flex items-center gap-3 p-3 rounded-lg transition-all relative group ${viewMode === 'waves' ? 'bg-blue-600/10 text-blue-400' : 'text-slate-400 hover:bg-white/5'}`}
          >
            <Globe size={18} className={viewMode === 'waves' ? 'text-blue-400' : 'group-hover:text-white'} />
            <span className="text-sm font-medium group-hover:text-white">Waves Productivas</span>
            {viewMode === 'waves' && <div className="absolute left-0 top-2 bottom-2 w-1 bg-blue-500 rounded-full" />}
          </a>
          <a href="#" className="flex items-center gap-3 p-3 rounded-lg text-slate-400 hover:bg-white/5 transition-all group">
            <Activity size={18} className="group-hover:text-white" />
            <span className="text-sm font-medium group-hover:text-white">Métricas Globales</span>
          </a>
          <a href="#" className="flex items-center gap-3 p-3 rounded-lg text-slate-400 hover:bg-white/5 transition-all group">
            <Clock size={18} className="group-hover:text-white" />
            <span className="text-sm font-medium group-hover:text-white">Programación</span>
          </a>

          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-8 mb-4">Idiomas</div>
          <div className="space-y-2 px-1">
            {['EN <> ES', 'EN <> FR', 'EN <> ZH'].map(pair => (
              <label key={pair} className="flex items-center gap-3 text-xs text-slate-400 hover:text-slate-200 cursor-pointer transition-colors">
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-blue-500 focus:ring-blue-500/20 focus:ring-offset-0" />
                {pair}
              </label>
            ))}
          </div>
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-800 text-[10px] text-slate-500">
          <p className="flex justify-between"><span>Servidor:</span> <span className="text-slate-400 font-mono">Latam-North-01</span></p>
          <p className="flex justify-between mt-1"><span>Latencia:</span> <span className="text-emerald-500 font-mono">24ms</span></p>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-h-screen">
        {/* Header */}
        <header className="h-20 glass border-b border-[#1E293B] flex items-center justify-between px-8 sticky top-0 z-20 backdrop-blur-md">
          <div className="flex gap-12 items-center">
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">En Línea</span>
              <span className="text-2xl font-bold tracking-tighter">1,248</span>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Ocupación</span>
              <span className="text-2xl font-bold tracking-tighter text-emerald-400">84.2%</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-white leading-none">Carlos Ruiz</p>
              <p className="text-[10px] text-blue-400 font-medium uppercase mt-1">Superintendente de Turno</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-slate-800 border-2 border-slate-700 flex items-center justify-center shrink-0">
              <Users className="text-slate-400" size={20} />
            </div>
          </div>
        </header>

        <main className="p-8 space-y-8 flex-1">
          {/* Controls */}
          <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
            <div className="relative w-full md:w-96 group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
              <input 
                type="text" 
                placeholder="Buscar intérprete (Nombre, ID, Idioma)..." 
                className="w-full pl-12 pr-4 py-3 bg-slate-900/50 border border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm font-medium placeholder:text-slate-600"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="flex gap-1 p-1 bg-slate-900/80 border border-slate-800 rounded-xl overflow-x-auto scrollbar-hide">
                {(['all', 'available', 'on-call', 'break', 'offline'] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setStatusFilter(s)}
                    className={`px-4 py-1.5 text-[10px] uppercase font-bold rounded-lg transition-all whitespace-nowrap ${
                      statusFilter === s 
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                        : 'text-slate-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>

              <div className="h-8 w-px bg-slate-800 shrink-0" />

              <div className="flex gap-1 p-1 bg-slate-900/80 border border-slate-800 rounded-xl">
                 <button 
                  onClick={() => setViewMode('grid')}
                  className={`p-1.5 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-200'}`}
                 >
                   <LayoutGrid size={16} />
                 </button>
                 <button 
                  onClick={() => setViewMode('table')}
                  className={`p-1.5 rounded-lg transition-all ${viewMode === 'table' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-200'}`}
                 >
                   <List size={16} />
                 </button>
              </div>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {viewMode === 'waves' ? (
              <motion.section 
                key="waves"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                {MOCK_WAVES.map((wave) => (
                  <WaveCard key={wave.id} wave={wave} />
                ))}
              </motion.section>
            ) : viewMode === 'grid' ? (
              <motion.section 
                key="grid"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
              >
                {filteredInterpreters.map((interpreter) => (
                  <InterpreterCard 
                    key={interpreter.id} 
                    interpreter={interpreter} 
                    onClick={() => setSelectedInterpreter(interpreter)}
                  />
                ))}
              </motion.section>
            ) : (
              <motion.section 
                key="table"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="glass rounded-3xl overflow-hidden border border-slate-800"
              >
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-900/50 border-b border-slate-800">
                        <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-500">ID</th>
                        <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-500">Intérprete</th>
                        <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-500">Estado</th>
                        <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-500">Idiomas</th>
                        <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-500">AHT</th>
                        <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-500 text-center">CSAT</th>
                        <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-500 text-right">Acción</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {filteredInterpreters.map(interpreter => (
                        <tr 
                          key={interpreter.id} 
                          onClick={() => setSelectedInterpreter(interpreter)}
                          className="hover:bg-white/5 transition-colors cursor-pointer group"
                        >
                          <td className="px-6 py-4 font-mono text-[11px] text-slate-500 group-hover:text-blue-400">{interpreter.id}</td>
                          <td className="px-6 py-4">
                            <div className="font-bold text-white text-sm">{interpreter.name}</div>
                            <div className="text-[10px] text-slate-500">{interpreter.email}</div>
                          </td>
                          <td className="px-6 py-4">
                            <div className={`inline-flex items-center gap-2 px-2 py-0.5 rounded-full border ${getStatusBorderClass(interpreter.status)} ${getStatusTextClass(interpreter.status)} bg-current/5`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${getStatusBgClass(interpreter.status)}`} />
                              <span className="text-[9px] font-bold uppercase tracking-widest">{interpreter.status}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex gap-1 overflow-hidden">
                              {interpreter.languages.map(lang => (
                                <span key={lang} className="text-[9px] font-bold uppercase border border-white/10 px-1.5 py-0.5 rounded bg-white/5 text-slate-300">
                                  {lang}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="px-6 py-4 font-mono text-xs text-slate-400">{interpreter.metrics.aht}</td>
                          <td className="px-6 py-4 text-center">
                            <div className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                              <Star size={10} fill="currentColor" />
                              {interpreter.metrics.csat}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <button className="p-2 text-slate-500 hover:text-white transition-colors">
                              <ArrowUpRight size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.section>
            )}
          </AnimatePresence>

          {filteredInterpreters.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 bg-slate-900/20 rounded-3xl border border-dashed border-slate-800">
              <div className="w-16 h-16 bg-slate-800/50 rounded-full flex items-center justify-center mb-4">
                <Search className="text-slate-600" size={32} />
              </div>
              <p className="text-slate-400 font-medium italic">No se encontraron intérpretes con los criterios actuales.</p>
            </div>
          )}
        </main>

        <footer className="h-14 border-t border-[#1E293B] bg-[#0A0C10]/80 backdrop-blur-md flex items-center justify-between px-8 shrink-0">
          <div className="flex items-center gap-8 text-[10px] font-bold uppercase tracking-wider text-slate-500">
            <span className="flex items-center gap-2">Cola Médica: <span className="text-emerald-500">0</span></span>
            <span className="flex items-center gap-2">Cola Legal: <span className="text-amber-500 font-mono">3</span></span>
            <span className="flex items-center gap-2">Cola Social: <span className="text-blue-500">1</span></span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-500">Sistemas Operativos</span>
          </div>
        </footer>
      </div>

      {/* Detail Overlay */}
      <AnimatePresence>
        {selectedInterpreter && (
          <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-md">
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="w-full max-w-lg h-full glass border-l border-white/10 shadow-[-20px_0_50px_rgba(0,0,0,0.5)] flex flex-col"
            >
              <div className="p-8 border-b border-white/5 flex justify-between items-center">
                <div>
                  <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-blue-500 mb-1">Perfil del Agente</h2>
                  <p className="text-lg font-bold tracking-tight">Expediente de Personal</p>
                </div>
                <button 
                  onClick={() => setSelectedInterpreter(null)}
                  className="w-10 h-10 flex items-center justify-center hover:bg-white/5 rounded-full transition-colors border border-white/5 text-slate-400 hover:text-white"
                >
                  <ArrowUpRight className="rotate-45" size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-10 custom-scrollbar">
                <div className="flex items-center gap-6">
                  <div className="w-24 h-24 bg-slate-800 rounded-3xl flex items-center justify-center text-4xl border border-white/10 font-bold group overflow-hidden relative shadow-2xl">
                    <div className="absolute inset-x-0 bottom-0 h-1/3 bg-blue-600/20 backdrop-blur-sm" />
                    <span className="relative text-white/50 group-hover:text-blue-400 transition-colors">
                      {selectedInterpreter.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold tracking-tighter text-white">{selectedInterpreter.name}</h3>
                    <p className="text-sm font-mono text-slate-400 flex items-center gap-2 mt-1">ID: <span className="text-blue-400">{selectedInterpreter.id}</span></p>
                    <div className={`mt-3 inline-flex items-center gap-2 px-3 py-1 transparent border rounded-full ${getStatusBorderClass(selectedInterpreter.status)}`}>
                      <span className={`w-2 h-2 rounded-full animate-pulse ${getStatusBgClass(selectedInterpreter.status)}`} />
                      <span className="text-[10px] font-bold uppercase tracking-widest">{selectedInterpreter.status}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <DetailStat label="Llamadas" value={selectedInterpreter.metrics.callsTaken} icon={<PhoneCall size={14} />} />
                  <DetailStat label="AHT" value={selectedInterpreter.metrics.aht} icon={<Clock size={14} />} />
                  <DetailStat label="CSAT" value={`${selectedInterpreter.metrics.csat}/5`} icon={<Star size={14} className="text-amber-500 fill-amber-500" />} />
                  <DetailStat label="Wave" value={MOCK_WAVES.find(w => w.id === selectedInterpreter.waveId)?.name || 'N/A'} icon={<Globe size={14} />} />
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] uppercase font-bold text-slate-500 tracking-[0.2em]">Competencia Lingüística</label>
                  <div className="flex flex-wrap gap-2">
                    {selectedInterpreter.languages.map(lang => (
                      <span key={lang} className="px-4 py-2 bg-blue-600/10 border border-blue-600/20 text-blue-400 text-[11px] font-bold uppercase tracking-widest rounded-xl transition-all hover:bg-blue-600 hover:text-white cursor-default">
                        {lang}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] uppercase font-bold text-slate-500 tracking-[0.2em]">Especialidades Certificadas</label>
                  <div className="space-y-3">
                    {selectedInterpreter.specialties.map(spec => (
                      <div key={spec} className="flex items-center justify-between bg-white/3 border border-white/5 rounded-2xl p-4 group hover:bg-white/5 transition-all">
                        <div>
                          <span className="text-sm font-bold text-slate-200 block">{spec}</span>
                          <span className="text-[10px] text-slate-500 uppercase tracking-wider">Certificado Tier 1</span>
                        </div>
                        <div className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                          <span className="text-[9px] font-bold uppercase text-emerald-400">Verificado</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-8 border-t border-white/5 bg-black/40 flex gap-4">
                <button className="flex-1 bg-blue-600 text-white py-4 rounded-2xl font-bold uppercase text-xs tracking-[0.2em] hover:bg-blue-700 hover:shadow-[0_0_25px_rgba(37,99,235,0.4)] transition-all active:scale-95">
                  Asignar a Llamada
                </button>
                <button className="w-14 h-14 rounded-2xl border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/5 transition-all">
                  <MoreVertical size={20} />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

interface InterpreterCardProps {
  interpreter: Interpreter;
  onClick: () => void;
}

const InterpreterCard: React.FC<InterpreterCardProps> = ({ interpreter, onClick }) => {
  const waveName = MOCK_WAVES.find(w => w.id === interpreter.waveId)?.name || 'N/A';

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      onClick={onClick}
      className={`glass group p-6 rounded-3xl cursor-pointer transition-all border-l-4 ${getStatusBorderClass(interpreter.status)}`}
    >
      <div className="flex justify-between items-start mb-6">
        <div className="flex gap-4 items-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 border border-white/5 flex items-center justify-center font-bold text-slate-400 group-hover:text-white group-hover:border-blue-500/50 transition-all overflow-hidden relative">
            {interpreter.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div>
            <h3 className="font-bold text-white tracking-tight">{interpreter.name}</h3>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mt-0.5">ID: {interpreter.id}</p>
          </div>
        </div>
        <span className={`px-2 py-1 rounded-lg text-[9px] font-bold uppercase tracking-widest border ${getStatusTextClass(interpreter.status)} border-current bg-current/5`}>
          {interpreter.status}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-slate-900/50 border border-white/3 p-3 rounded-2xl group-hover:border-white/10 transition-colors">
          <p className="text-[10px] text-slate-500 uppercase font-bold tracking-tight mb-1">Idiomas</p>
          <p className="text-[11px] font-bold tracking-tighter truncate text-slate-300">
            {interpreter.languages.join(' • ')}
          </p>
        </div>
        <div className="bg-slate-900/50 border border-white/3 p-3 rounded-2xl group-hover:border-white/10 transition-colors">
          <p className="text-[10px] text-slate-500 uppercase font-bold tracking-tight mb-1">Wave</p>
          <div className="flex items-center gap-1.5">
             <span className="text-[11px] font-bold text-white uppercase">{waveName}</span>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${(parseFloat(interpreter.metrics.aht.split(':')[0]) / 10) * 100}%` }}
            className="h-full bg-blue-500 rounded-full" 
          />
        </div>
        <div className="flex justify-between text-[9px] font-bold uppercase tracking-[0.2em] text-slate-500">
          <span>Rendimiento AHT</span>
          <span className="text-blue-400">{interpreter.metrics.aht} min</span>
        </div>
      </div>
    </motion.div>
  );
};

const WaveCard: React.FC<{ wave: Wave }> = ({ wave }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass p-6 rounded-3xl border border-white/5 space-y-6"
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-bold tracking-tighter text-white">{wave.name}</h3>
          <p className="text-[10px] font-mono text-blue-400 uppercase tracking-widest mt-1">Prod: {wave.startDate}</p>
        </div>
        <div className="w-10 h-10 bg-blue-600/10 rounded-xl flex items-center justify-center text-blue-500">
          <Globe size={20} />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <p className="text-[9px] font-bold uppercase text-slate-500 tracking-wider">Dotación</p>
          <p className="text-lg font-bold text-white">{wave.interpreterCount} <span className="text-xs text-slate-500 font-normal">Agentes</span></p>
        </div>
        <div className="space-y-1">
          <p className="text-[9px] font-bold uppercase text-slate-500 tracking-wider">CSAT Prom</p>
          <div className="flex items-center gap-1.5">
            <Star size={12} className="text-amber-500 fill-amber-500" />
            <p className="text-lg font-bold text-white">{wave.averageCsat}</p>
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-white/5">
        <div className="flex items-center justify-between text-[10px] font-bold uppercase text-slate-400 mb-2">
           <span>Capacidad</span>
           <span>100%</span>
        </div>
        <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full bg-emerald-500 w-full" />
        </div>
      </div>
    </motion.div>
  );
};

function DetailStat({ label, value, icon }: { label: string, value: string | number, icon: ReactNode }) {
  return (
    <div className="p-6 bg-white/3 border border-white/5 rounded-3xl transition-all hover:bg-white/5 group">
      <div className="flex items-center gap-2 text-[9px] uppercase font-bold text-slate-500 tracking-[0.2em] mb-2 group-hover:text-blue-400 transition-colors">
        {icon}
        {label}
      </div>
      <div className="text-xl font-bold tracking-tighter text-white">{value}</div>
    </div>
  );
}

function getStatusBorderClass(status: InterpreterStatus) {
  switch (status) {
    case 'available': return 'border-emerald-500/50';
    case 'on-call': return 'border-amber-500/50';
    case 'break': return 'border-red-500/50';
    case 'training': return 'border-blue-500/50';
    case 'offline': return 'border-slate-800';
    default: return 'border-slate-800';
  }
}

function getStatusBgClass(status: InterpreterStatus) {
  switch (status) {
    case 'available': return 'bg-emerald-500';
    case 'on-call': return 'bg-amber-500';
    case 'break': return 'bg-red-500';
    case 'training': return 'bg-blue-500';
    case 'offline': return 'bg-slate-500';
    default: return 'bg-slate-500';
  }
}

function getStatusTextClass(status: InterpreterStatus) {
  switch (status) {
    case 'available': return 'text-emerald-400';
    case 'on-call': return 'text-amber-400';
    case 'break': return 'text-red-400';
    case 'training': return 'text-blue-400';
    case 'offline': return 'text-slate-500';
    default: return 'text-slate-500';
  }
}
